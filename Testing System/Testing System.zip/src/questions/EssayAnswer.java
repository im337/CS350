package questions;

public class EssayAnswer extends Question{

    public EssayAnswer(String p) {
        prompt = p;
    }

    public String display(){
        return prompt;
    }

}
