package tests;

import main.Main;

import java.io.IOException;

public class MainTest {

    public static void main(String args[]) throws IOException, ClassNotFoundException {
        Main.MainMenu();
    }
}
